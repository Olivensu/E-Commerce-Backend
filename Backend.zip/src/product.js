const data = {
    product: [
        {
            name: 'Tasbiul Hasan',
            email: 'tasbiul@gmail.com',
            password:'1234567',
            phone: '01789888842',
            address: 'Sylhet, Bangladesh',
        },
        {
            name: 'Tasbiul Olive',
            email: 'tasbiulolive@gmail.com',
            password:'1234567',
            phone: '01789888842',
            address: 'Dhaka, Bangladesh',
        },
    ]
}
module.exports = data